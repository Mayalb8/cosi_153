import App from './components/TabDemo';
export default App;