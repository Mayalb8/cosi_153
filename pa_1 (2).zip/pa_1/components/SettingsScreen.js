import React, {useState} from 'react';
import { Text, View, TextInput } from 'react-native';
import {useValue} from './ValueContext';

function SettingsScreen() {
    const {currentValue} = useValue();
    const [status, setStatus] = useState([]);
    const [my_name, setmy_name] = useState('');
    currentValue['username']=my_name;
    currentValue['status']=status;
    
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Settings</Text>
        <Text>Username: {currentValue.username}</Text>
        <TextInput 
                style={{height: 40, borderColor: 'gray', borderWidth: 1}}
                onChangeText={text => setmy_name(text)}
                value={my_name} />
                
        <Text>Status: {currentValue.status}</Text>
                <TextInput 
                style={{height: 40, borderColor: 'gray', borderWidth: 1}}
                onChangeText={text => setStatus(text)}
                value={status} />
      </View>
    );
  }

export default SettingsScreen;

  