import React, {useState} from 'react';
import { Text, View, TextInput, Button } from 'react-native';
import {useValue} from './ValueContext';


function About() {
    const [pass_word, setpass_word] = useState('');
    const [my_name, setmy_name] = useState('');
    const {currentValue, setCurrentValue} = useValue();
    //currentValue['username']=my_name;
    //currentValue['status']=pass_word;

    return (
      <View style={{flex:1, justifyContent: 'center', alignItems: 'stretch' }}>
        <Text>Welcome to myHouse!</Text>
        <Text>Here we help you organize your home!</Text>
        <Text>  </Text>
        <Text>Username: </Text>
        <TextInput 
                style={{height: 40, borderColor: 'gray', borderWidth: 1}}
                onChangeText={text=> setmy_name(text)}
                value={my_name}
                />
        <Button
                title='Save'
                onPress={() => {
                    setCurrentValue({...currentValue, username:my_name});
                    setmy_name('');
                }} />
        <Text>Status: </Text>
                <TextInput 
                style={{height: 40, borderColor: 'gray', borderWidth: 1}}
                onChangeText={text=> setpass_word(text)}
                value={pass_word}
                />
        <Button
                title='Save'
                onPress={() => {
                    setCurrentValue({...currentValue, status: pass_word});
                    setpass_word('');
                }} />
      </View>
      
    );
  }

export default About;
