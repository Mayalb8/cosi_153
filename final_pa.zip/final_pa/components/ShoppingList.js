import React, {useState} from 'react';
import {StyleSheet, Text, View, TextInput, Button, FlatList } from 'react-native';
import {useValue} from './ValueContext'; 
import ToDoList from './ToDoList';
          //<Text>{shoppinglist}</Text>
          //<Text>{JSON.stringify(shoppinglist)}</Text>
import Tab from './TabDemo';

      //<Text>{JSON.stringify(currentValue)}</Text>
function completedCheck(fridges) {
  return fridges['completed']==false;
}
function ShoppingList(name, vist, list) {
    const {currentValue,setCurrentValue} = useValue();

    let texter=[]
    for (let i = 0; i < currentValue.shoppinglist.length; i++) {
    texter.push(currentValue.shoppinglist[i].title);
    }
    
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Button
        title='update'
        onPress={() => {
              let shoppingList_from_fridge = currentValue.shoppinglist;
              const newest_list=shoppingList_from_fridge.filter(completedCheck);
              //setCurrentValue({...currentValue, todos:shoppingList_from_fridge});
              setCurrentValue({...currentValue,shoppinglist:newest_list});
              //incrChanges()
                }} />
          <Text>This is the shopping list: </Text>
          <Text>{JSON.stringify(texter)}</Text>
      </View>
    );
  }

export default ShoppingList;

  