import React from 'react';
import { Text, View } from 'react-native';
import {useValue} from './ValueContext';


function HomeScreen() {
    const {currentValue} = useValue();
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Welcome to MyHouse</Text>
        <Text>an app which helps you organize your home!</Text>
        <Text>Username: {currentValue.username}</Text>
        <Text>Status: {currentValue.status}</Text>
      </View>
      
    );
  }

export default HomeScreen;

  