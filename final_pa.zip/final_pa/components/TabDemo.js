import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import HomeScreen from './HomeScreen';
import FridgeScreen from './FridgeScreen';
import About from './About';
import ValueProvider from './ValueContext';
import ShoppingList from './ShoppingList';
import ToDoList from './ToDoList';
import Recipes from './Recipes';
import BuyThis from './buythis';


const Tab = createBottomTabNavigator();

export default function App() {
  const data = {username:'',status:'',fridge:[], shoppinglist:[], todos:[]};

  return (
   <ValueProvider value={data}>
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Settings" component={About}/>
        <Tab.Screen name="Home" component={HomeScreen} />
        <Tab.Screen name="Fridge" component={FridgeScreen}/>
        <Tab.Screen name="Manage Purchases" component={BuyThis}/>
        <Tab.Screen name="ShoppingList" component={ShoppingList}/>
        <Tab.Screen name="Meal Suggestions" component={Recipes}/>
      </Tab.Navigator>
    </NavigationContainer>
   </ValueProvider>
  );
}