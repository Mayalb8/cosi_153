import React, {useState} from 'react';
import {StyleSheet, Text, View, TextInput, Button, FlatList } from 'react-native';
import {useValue} from './ValueContext'; 

const Item = ({ item, incrChanges }) => (
    <View style={styles.item}>
        <Text>{item['title']}</Text>
        <Button title="Done" onPress={() => {
              incrChanges()
              item['completed']=true
              }} />

    </View>

);

const FridgeScreen = () => {
    const [food, setFood] = useState('');
    const {currentValue, setCurrentValue} = useValue();
    const [changes, setChanges] = useState(0);


    const incrChanges = () => {
        setChanges(changes+1);
    }

    return (
        <View style={{flex:1, justifyContent: 'center', alignItems: 'stretch' }}>
            <Text>Fridge</Text>
            <TextInput 
                style={{height: 40, borderColor: 'gray', borderWidth: 1}}
                onChangeText={text => setFood(text)}
                value={food} />
            <Button
                title="Add food"
                onPress={() => {
                    let todo_item = {title:food, completed:false};
                    //setTodos([...todos, todo_item]);
                    let new_fridges=currentValue.fridge.concat(todo_item);
                    setCurrentValue({...currentValue, fridge:new_fridges});
                    //setFridge(new_fridges)
                    setFood('');
                }} />
            <FlatList
                data={currentValue.fridge.filter(item => !item['completed'])}
                extraData={changes}
                renderItem={({item}) =>  <Item item={item} incrChanges={incrChanges}/> }
                keyExtractor={item => item['title']}
             />
        </View>
    );
    }

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    item: {
        backgroundColor: '#f9c2ff',
        padding: 20,
        marginVertical: 8,
        marginHorizontal: 16,
        borderColor:'blue',
        borderWidth: 1,
    },
});

export default FridgeScreen;